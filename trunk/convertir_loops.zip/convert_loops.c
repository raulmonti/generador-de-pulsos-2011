#include <stdio.h>
#include <stdbool.h>
#include "instruction_sheet.h"
#include "instruction.h"
#include "instruction_list.h"
#include "instruction_stack.h"

instruction_list get_loops_insts(instruction initial_inst, instruction final_inst, instruction_sheet is);
void instruction_sheet_replace(instruction_sheet is, instruction initial, instruction final, instruction_list replacement);
instruction_list repeat_insts(instruction_list list, unsigned int n_times);
instruction_sheet convert_loops(instruction_sheet inst_sheet);


instruction_list get_loops_insts(instruction initial_inst, instruction final_inst, instruction_sheet is){
	bool found = false;
	unsigned int i = 0;
	
	instruction_list result = instruction_list_create();
	
	while((i < instruction_sheet_instruction_count(is)) && !found){
		found = (initial_inst == instruction_sheet_get_nth_instruction(is, i));
		i++;
	}
	if(found){
		while((i < instruction_sheet_instruction_count(is)) && 
			(instruction_sheet_get_nth_instruction(is, i) != final_inst)){
			instruction_list_add(result, instruction_sheet_get_nth_instruction(is, i));
			i++;
		}
	}
	return result;
}

void instruction_sheet_replace(instruction_sheet is, instruction initial, instruction final, instruction_list replacement){
	unsigned int from = 0;
	unsigned int to = 0;
	printf("***********************************************");
	instruction_print(initial);
	instruction_print(final);
	printf("***********************************************");
	
	while((from < instruction_sheet_instruction_count(is)) && 
			(instruction_sheet_get_nth_instruction(is, from) != initial)){
		from++;
	}
	
	to = from;
	
	while((to < instruction_sheet_instruction_count(is)) && 
			(instruction_sheet_get_nth_instruction(is, to) != final)){
		to++;
	}
	
	instruction_sheet_print(is);
	getchar();
	printf("**********************\n");
	instruction_sheet_remove_instructions(is, from, to);
	
	instruction_sheet_print(is);
	getchar();
	
	instruction_sheet_insert_instructions(is, instruction_list_get_list(replacement), from);
}

instruction_list repeat_insts(instruction_list list, unsigned int n_times){
	instruction_list result = instruction_list_create();
	unsigned int i = 0, j = 0;
	instruction shift = NULL;
	
	for(i=0; i < n_times; i++){
		shift = instruction_create(0, PHASE_SHIFT_CODE, 0);
		instruction_list_add(result, shift);
		for(j=0; j < instruction_list_length(list); j++){
			instruction_list_add(result, instruction_list_nth_item(list, j));
		}
	}
	return result;
}

			/*printf("****************----------SIN ESTIRAR---------**************\n");
			instruction_list_print(loop_inst_list, 1);
			getchar();
			printf("****************----------ESIRADA---------**************\n");
			instruction_list_print(stretched_loop_list, 1);
			getchar();*/
			

instruction_sheet convert_loops(instruction_sheet inst_sheet){
	unsigned int i = 0;
	instruction inst = NULL;
	instruction_list loop_inst_list = NULL, stretched_loop_list = NULL;
	instruction_stack st = instruction_stack_create();
	instruction_sheet stretched_is = instruction_sheet_create();
	
	for(i=0;i<instruction_sheet_instruction_count(inst_sheet);i++){
		
		inst = instruction_sheet_get_nth_instruction(inst_sheet, i);
		if((instruction_get_type(inst) == LOOP_INST_CODE) && instruction_is_phase_shifted(inst)){
			instruction_stack_push(st, inst);
		}else if(instruction_get_type(inst) == ENDLOOP_INST_CODE){
			loop_inst_list = get_loops_insts(instruction_stack_top(st), inst, inst_sheet);
			stretched_loop_list = repeat_insts(loop_inst_list, -instruction_get_data(instruction_stack_top(st)));
			instruction_sheet_replace(inst_sheet, instruction_stack_top(st), inst, stretched_loop_list);
			instruction_stack_pop(st);
			getchar();
		}
	}
	/*st = instruction_stack_destroy(st);*/
	return stretched_is;
}

int main(void){
	instruction_sheet inst_sheet = instruction_sheet_create(), nuevo_inst = NULL;
	
	instruction inst1 = instruction_create(1, PULSE_INST_CODE, 1);
	instruction inst2 = instruction_create(2, LOOP_INST_CODE, 2);
	instruction inst3 = instruction_create(3, PULSE_INST_CODE, 1);
	instruction inst4 = instruction_create(4, LOOP_INST_CODE, 2);
	instruction inst6 = instruction_create(6, DELAY_INST_CODE, 1);
	instruction inst7 = instruction_create(7, ENDLOOP_INST_CODE, 1);
	instruction inst8 = instruction_create(8, PULSE_INST_CODE, 1);
	instruction inst9 = instruction_create(9, ENDLOOP_INST_CODE, 1);
	
	instruction_set_phase_shift(inst2, true);
	instruction_set_phase_shift(inst4, true);
	instruction_sheet_add_instruction(inst_sheet, inst1);
	instruction_sheet_add_instruction(inst_sheet, inst2);
	instruction_sheet_add_instruction(inst_sheet, inst3);
	instruction_sheet_add_instruction(inst_sheet, inst4);
	instruction_sheet_add_instruction(inst_sheet, inst6);
	instruction_sheet_add_instruction(inst_sheet, inst7);
	instruction_sheet_add_instruction(inst_sheet, inst8);
	instruction_sheet_add_instruction(inst_sheet, inst9);
	
	/*printf("Hoja de instrucciones original\n");
	instruction_sheet_print(inst_sheet);
	getchar();*/
	nuevo_inst = convert_loops(inst_sheet);
	/*printf("*******************************************************");
	printf("Hoja de instrucciones \"estirada\"");
	instruction_sheet_print(nuevo_inst);
	
	inst_sheet = instruction_sheet_destroy(inst_sheet);*/
	return 0;
}
